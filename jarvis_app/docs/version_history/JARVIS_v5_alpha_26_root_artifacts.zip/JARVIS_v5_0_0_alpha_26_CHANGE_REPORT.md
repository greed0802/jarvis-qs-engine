# Jarvis v5.0.0-alpha.26 Change Report

## Version

v5.0.0-alpha.26 — Legacy Builder Bridge Shadow Import / Readiness Probe, no workbook read

## Base

v5.0.0-alpha.25 — Legacy Builder Engine Bridge Readiness Audit, still no engine

## Files added

- `jarvis_v5/tools/builder/legacy_bridge_shadow_probe.py`
- `jarvis_v5/tests/smoke/test_alpha26_legacy_bridge_shadow_probe.py`
- `jarvis_v5/tests/packs/alpha26_legacy_bridge_shadow_probe_tests.json`
- `jarvis_v5/docs/ALPHA_26_SCOPE.md`
- `jarvis_v5/docs/LEGACY_BRIDGE_SHADOW_PROBE_CONTRACT.md`
- `jarvis_v5/docs/PROTECTED_BUILDER_BOUNDARY_HASH_MANIFEST_ALPHA_26.md`
- `START_JARVIS_V5_ALPHA_26.bat`
- `START_JARVIS_V5_ALPHA_26_SIMPLE_NO_RELOAD.bat`

## Files changed

- `jarvis_v5/config.py`
- `jarvis_v5/app.py`
- `jarvis_v5/schemas/message_schema.py`
- `jarvis_v5/qa_runner/test_executor.py`
- retained smoke tests / JSON packs updated for alpha.26 version assertions
- `README.md`

## What changed

Added a metadata-only Legacy Builder bridge shadow probe endpoint. The probe reports bridge stub availability, contract readiness, execution locks, missing contract fields, and blocked-by-policy reasons. It does not import/call the legacy Builder, read workbooks, generate formulas, create preview rows, or create Excel.

## Protected boundaries

10 / 10 protected Builder boundary files remained unchanged.
