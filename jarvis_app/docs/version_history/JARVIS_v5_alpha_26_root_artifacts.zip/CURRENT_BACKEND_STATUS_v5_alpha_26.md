# Current Backend Status — v5.0.0-alpha.26

Status: accepted build candidate after sandbox tests.

Alpha.26 adds the Legacy Builder bridge shadow probe as a metadata-only endpoint. The future legacy bridge remains blocked by policy: workbook read disabled, legacy Builder callable disabled, Excel output disabled, and execution kill switch active.

No engine execution is connected.
