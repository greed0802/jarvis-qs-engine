# Jarvis v5.0.0-alpha.6 Test Report

## Automated tests

- Python compile check: PASS
- Full pytest smoke suite: PASS
- New alpha.6 attachment binding tests: PASS

## Smoke result

44 passed

## New coverage

1. Attachment binds workbook metadata to active Builder task.
2. `/api/plan` displays public workbook metadata without `saved_path`.
3. Snapshot captures workbook_ref.
4. Adapter dry-run captures workbook_ref and returns `workbook_read=false`.
5. Attachment-only upload without active task does not create a Builder task.
6. Duplicate attachment event does not rebind workbook.
