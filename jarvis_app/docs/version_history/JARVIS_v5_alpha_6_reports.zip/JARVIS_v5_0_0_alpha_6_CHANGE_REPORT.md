# Jarvis v5.0.0-alpha.6 Change Report

## Base

v5.0.0-alpha.5.1 — Adapter Dry Run Freshness + Plan Display Polish

## Changes

1. Added workbook metadata binding to active Builder tasks.
2. Added `workbook_ref` propagation into BuilderRunSnapshot.
3. Added `workbook_ref` propagation into Builder Adapter Dry Run input.
4. Added `workbook_read=false` safety proof to adapter responses, trace payload, and schemas.
5. Added workbook metadata display to `/api/plan` and Review.
6. Attachment-only uploads without an active task are stored/acknowledged but do not create a Builder task.
7. Duplicate attachment events return cached responses and do not rebind the workbook.
8. Kept snapshot stale logic and adapter freshness logic.

## Not touched

- Builder engine
- Workbook reading/parsing
- Formula generation
- Formatter
- QA Checker
- O&A
- Preview/export engine
- UI redesign
- Current Jarvis replacement
