# Jarvis v5.0.0-alpha.12.2 Change Report

## Base used

v5.0.0-alpha.12.1 — Test Pack Import Guard + Fixture Attach Support, no engine.

## Changed

- `jarvis_v5/config.py`
- `jarvis_v5/qa_runner/report_writer.py`
- `jarvis_v5/qa_runner/test_executor.py`
- `jarvis_v5/tests/smoke/test_alpha12_qa_runner.py`
- `jarvis_v5/tests/smoke/test_alpha12_1_import_guard_fixture_attach.py`

## Added

- `jarvis_v5/tests/smoke/test_alpha12_2_report_dir_sample_pack.py`
- `jarvis_v5/docs/ALPHA_12_2_SCOPE.md`
- `START_JARVIS_V5_ALPHA_12_2.bat`
- `START_JARVIS_V5_ALPHA_12_2_SIMPLE_NO_RELOAD.bat`

## Fixes

1. QA report writer now recreates `jarvis_v5/data/test_reports` before writing JSON/Markdown reports.
2. QA runner catches report-writing exceptions and returns a structured `report_write_error` instead of raw 500.
3. Endpoint-specific top-level safety warnings are no longer emitted for adapter/contract/replay endpoints where those top-level safety fields are expected.
4. Sample external AI pack passes with both report writing enabled and disabled.

## Protected / not touched

No Builder engine, no workbook reading/parsing, no formula generation, no Excel output, no Formatter, no QA, no O&A, no UI redesign, no current Jarvis replacement.
