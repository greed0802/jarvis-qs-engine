# Jarvis v5.0.0-alpha.12 — Change Report

## Base used

`v5.0.0-alpha.11 — Contract Negative Guards + Contract Replay Debug, no engine`

## Scope

Local QA Test Runner + Importable Test Packs, no engine.

## Added

1. Local API test runner modules under `jarvis_v5/qa_runner/`.
2. Built-in test pack: `jarvis_v5/tests/packs/alpha11_contract_negative_guards.json`.
3. Importable JSON test-pack support.
4. Ordered POST/GET API step execution.
5. JSON-path style assertions: equals, not_equals, contains, not_contains, exists, not_exists, is_true, is_false, includes_all.
6. Local JSON and Markdown report writer under `jarvis_v5/data/test_reports/`.
7. Dev endpoint: `POST /api/dev/run-smoke-tests`.
8. CLI script: `python run_alpha_smoke_tests.py`.
9. Tiny fixture file: `jarvis_v5/tests/fixtures/Test.xlsx` for metadata-only upload tests.
10. Alpha.12 smoke tests.

## Files changed

- `jarvis_v5/config.py`
- `jarvis_v5/app.py`
- `README.md`

## Files added

- `jarvis_v5/qa_runner/__init__.py`
- `jarvis_v5/qa_runner/assertions.py`
- `jarvis_v5/qa_runner/test_pack_schema.py`
- `jarvis_v5/qa_runner/test_pack_loader.py`
- `jarvis_v5/qa_runner/test_executor.py`
- `jarvis_v5/qa_runner/report_writer.py`
- `jarvis_v5/tests/packs/alpha11_contract_negative_guards.json`
- `jarvis_v5/tests/fixtures/Test.xlsx`
- `jarvis_v5/tests/smoke/test_alpha12_qa_runner.py`
- `jarvis_v5/docs/ALPHA_12_SCOPE.md`
- `jarvis_v5/data/test_reports/.keep`
- `run_alpha_smoke_tests.py`
- `START_JARVIS_V5_ALPHA_12.bat`
- `START_JARVIS_V5_ALPHA_12_SIMPLE_NO_RELOAD.bat`
- `JARVIS_v5_0_0_alpha_12_CHANGE_REPORT.md`
- `JARVIS_v5_0_0_alpha_12_TEST_REPORT.md`
- `JARVIS_v5_0_0_alpha_12_TEST_RUN_RESULTS.txt`

## Safety locks preserved

- `workbook_read=false`
- `engine_called=false`
- `excel_created=false`
- `contract_only=true`
- `legacy_builder_called=false`

## Protected / not touched

- No Builder engine
- No Formatter
- No QA Checker
- No O&A
- No formula generation
- No workbook reading/parsing
- No sheet inspection
- No actual Preview/Export
- No UI redesign
- No current Jarvis replacement
