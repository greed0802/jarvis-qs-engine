# Jarvis v5.0.0-alpha.12.1 — Change Report

## Version
v5.0.0-alpha.12.1 — Test Pack Import Guard + Fixture Attach Support, no engine

## Base used
v5.0.0-alpha.12 — Local QA Test Runner + Importable Test Packs, no engine

## Scope
Harden the local QA runner for external/AI-generated JSON test packs while keeping the Builder engine disconnected.

## Files changed
- `jarvis_v5/config.py`
- `jarvis_v5/app.py`
- `jarvis_v5/qa_runner/assertions.py`
- `jarvis_v5/qa_runner/test_pack_loader.py`
- `jarvis_v5/qa_runner/test_pack_schema.py`
- `jarvis_v5/qa_runner/test_executor.py`
- `jarvis_v5/tests/smoke/test_alpha12_qa_runner.py`
- `README.md`

## Files added
- `jarvis_v5/tests/packs/sample_external_ai_pack_valid.json`
- `jarvis_v5/tests/smoke/test_alpha12_1_import_guard_fixture_attach.py`
- `jarvis_v5/docs/ALPHA_12_1_SCOPE.md`
- `jarvis_v5/docs/EXTERNAL_AI_TEST_PACK_PROMPT.md`
- `START_JARVIS_V5_ALPHA_12_1.bat`
- `START_JARVIS_V5_ALPHA_12_1_SIMPLE_NO_RELOAD.bat`
- `JARVIS_v5_0_0_alpha_12_1_CHANGE_REPORT.md`
- `JARVIS_v5_0_0_alpha_12_1_TEST_REPORT.md`
- `JARVIS_v5_0_0_alpha_12_1_TEST_RUN_RESULTS.txt`

## What changed
1. Invalid/missing/bad-schema imported test packs now return structured `INVALID_PACK` responses.
2. `/api/dev/run-smoke-tests` returns HTTP 422 for invalid packs instead of raw 500.
3. Added `/api/dev/validate-test-pack` for preflight compatibility checks.
4. Added `file_fixture` syntax for `/api/attach` steps.
5. Added compatibility warnings for:
   - `json.file` attach misuse
   - unknown expected routes
   - likely endpoint-specific safety assertions
   - expecting contract creation before full setup/snapshot/adapter
6. Improved path-not-found assertion diagnostics with available top-level fields and hints.
7. Added a sample valid external AI test pack.

## Safety locks preserved
- `workbook_read=false`
- `engine_called=false`
- `excel_created=false`
- `contract_only=true`
- `legacy_builder_called=false`

## Protected / not touched
- No Builder engine
- No workbook reading/parsing
- No formula generation
- No Excel output
- No Formatter
- No QA
- No O&A
- No UI redesign
- No current Jarvis replacement
