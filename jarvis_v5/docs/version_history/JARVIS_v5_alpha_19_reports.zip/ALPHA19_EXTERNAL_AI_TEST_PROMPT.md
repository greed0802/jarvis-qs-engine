# Prompt for another AI — create alpha.19 weakness test JSON pack

Use this prompt in another chat/AI to create an importable JSON test pack.

```text
You are my Jarvis Development Partner.

Context:
I am testing Jarvis v5.0.0-alpha.19 — Contract Fixture Replay + Golden Diff Tests, no engine.

I need you to create an importable JSON test pack that targets current weak spots after alpha.19.

Do not patch/build Jarvis.
Do not create code outside the JSON pack.
Output ONLY valid JSON.
No markdown.
No explanations.
No comments.

Target version:
v5.0.0-alpha.19

Pack name:
alpha19_deep_contract_fixture_boundary_tests

Purpose:
Stress-test Jarvis alpha.19 around:
- contract fixture replay
- golden diff mismatch detection
- stale snapshot blocking
- stale adapter blocking
- pending clarification blocking
- execution kill switch
- safety envelope consistency
- plan visibility for fixture replay
- no-engine boundary

Safety requirements:
Every test must preserve:
- workbook_read_any_true = false
- engine_called_any_true = false
- excel_created_any_true = false
- legacy_builder_called_any_true = false

No test may expect:
- Builder engine call
- legacy Builder call
- workbook reading/parsing
- formula generation
- Excel output
- Formatter
- QA Checker
- O&A
- UI actions

Allowed endpoints:
- GET /api/version
- POST /api/chat
- POST /api/attach
- GET /api/plan/{conversation_id}
- POST /api/builder/create-snapshot
- POST /api/builder/adapter-dry-run
- POST /api/builder/engine-contract
- GET /api/builder/engine-contract/{contract_id}
- GET /api/builder/engine-contract/latest/{conversation_id}
- POST /api/builder/engine-boundary-audit
- POST /api/builder/engine-preflight
- POST /api/builder/engine-execution-request
- POST /api/builder/contract-fixture-replay

Allowed assertion operators:
- equals
- not_equals
- contains
- not_contains
- exists
- not_exists
- is_true
- is_false
- includes_all

Known routes:
- new_builder_task_shell
- active_task_slot_edit
- active_task_slot_edit_needs_clarification
- active_task_edit_unhandled
- clarification_resolved
- active_task_review
- active_task_preview_stub
- attachment_bind
- builder_snapshot_created
- builder_snapshot_blocked
- builder_adapter_dry_run
- builder_adapter_dry_run_blocked
- builder_engine_contract_created
- builder_engine_contract_blocked
- builder_engine_contract_replay
- builder_engine_contract_latest_replay
- builder_engine_contract_latest_not_found
- builder_engine_boundary_audit
- builder_engine_boundary_audit_blocked
- builder_engine_preflight_ready
- builder_engine_preflight_blocked
- builder_engine_execution_blocked
- builder_contract_fixture_replay
- builder_contract_fixture_replay_blocked

Use this file fixture format:
{
  "name": "attach_fixture_workbook",
  "method": "POST",
  "endpoint": "/api/attach",
  "form": {
    "conversation_id": "CONVERSATION_ID_HERE",
    "client_event_id": "UNIQUE_EVENT_ID_HERE",
    "text": "Here"
  },
  "file_fixture": "Test.xlsx",
  "assertions": [
    {"path": "$.route", "equals": "attachment_bind"},
    {"path": "$.reducer_result.workbook_read", "equals": false}
  ]
}

Create exactly 10 tests:

1. VERSION_ALPHA19_LOCKS
Expected:
- $.version = v5.0.0-alpha.19
- $.engines_connected.builder = false
- $.engines_connected.builder_contract_fixture_replay = false
- execution locks all false

2. WALL_TYPES_GOLDEN_REPLAY_CLEAN
Flow:
- Build me a BOQ
- Attach Test.xlsx
- Use Wall Types
- Use XGETWALLAREA
- Unit m2
- Zone 1: Old and New
- Use Head 2 for Zone 1
- Levels GF to L3
- create snapshot
- adapter dry run
- engine contract
- contract fixture replay fixture wall_types_xgetwallarea_zone1_head2_gf_l3_contract_v1
Expected:
- contract created
- fixture replay passed = true
- diff_status = clean
- diffs = []
- safety false

3. REINFORCEMENT_GOLDEN_REPLAY_CLEAN
Flow:
- Build me a BOQ
- Attach Test.xlsx
- Use Reinforcement
- Use XGETCUSTOM with Reinforcement Weight unit t
- Zone 1: Old and New
- Use Head 2 for Zone 1
- Levels GF to L3
- create snapshot
- adapter dry run
- engine contract
- contract fixture replay fixture reinforcement_xgetcustom_weight_t_zone1_head2_gf_l3_contract_v1
Expected:
- clarification_resolved = true
- contract created
- fixture replay passed = true
- actual_stable.builder_setup.trade_profile = Concrete / Reinforcement
- actual_stable.builder_setup.custom_quantity = Reinforcement Weight
- safety false

4. INTENTIONAL_MISMATCH_DETECTED_NO_ENGINE
Flow:
- complete Wall Types contract
- contract fixture replay with intentional_mismatch=true
Expected:
- route = builder_contract_fixture_replay
- passed = false
- diff_status = mismatch
- diffs exists
- engine_called = false
- excel_created = false

5. FIXTURE_NOT_FOUND_BLOCKS_SAFELY
Flow:
- POST /api/builder/contract-fixture-replay with fixture = does_not_exist
Expected:
- route = builder_contract_fixture_replay_blocked
- blocked = true
- reason = fixture_not_found
- safety false

6. PLAN_SHOWS_FIXTURE_REPLAY_AFTER_CLEAN_REPLAY
Flow:
- complete Wall Types contract
- fixture replay clean
- GET /api/plan/{conversation_id}
Expected:
- contract_fixture_replay.found = true
- contract_fixture_replay.diff_status = clean
- contract_fixture_replay.workbook_read = false
- engine_contract.found = true

7. STALE_SNAPSHOT_BLOCKS_CONTRACT_AND_FIXTURE_REPLAY_SELF_ONLY_STILL_SAFE
Flow:
- complete Wall Types setup
- create snapshot
- change Zone 1: Old and New and Same
- engine contract
- contract fixture replay without a current contract
Expected:
- contract route = builder_engine_contract_blocked
- contract reason = snapshot_is_stale or setup_not_ready_for_future_engine depending exact active state
- fixture replay still route = builder_contract_fixture_replay
- safety false

8. STALE_ADAPTER_BLOCKS_CONTRACT
Flow:
- complete Wall Types setup
- create snapshot
- adapter dry run
- change Levels GF to L5
- create snapshot
- engine contract
Expected:
- contract route = builder_engine_contract_blocked
- reason = adapter_is_stale
- safety false

9. PENDING_CLARIFICATION_BLOCKS_CONTRACT_PREFLIGHT_EXECUTION_FIXTURE_SAFE
Flow:
- Build me a BOQ
- Use Painting
- engine contract
- engine preflight
- engine execution request
- contract fixture replay wall fixture
Expected:
- Painting route = active_task_slot_edit_needs_clarification
- contract/preflight/execution blocked
- fixture replay safe/no-engine
- safety false

10. EXECUTION_STILL_LOCKED_AFTER_GOLDEN_REPLAY
Flow:
- complete Wall Types full chain through fixture replay
- boundary audit
- preflight
- engine execution request
Expected:
- boundary audit = builder_engine_boundary_audit
- preflight = builder_engine_preflight_ready
- execution = builder_engine_execution_blocked
- reason = engine_execution_disabled_by_kill_switch
- legacy_builder_called = false
- engine_called = false
- excel_created = false

Every conversation_id must be unique.
Every client_event_id must be unique.
Use only supported JSON-path assertions.
Avoid one-of-two route expectations unless the runner supports it.
If route uncertainty exists, assert safer /api/plan results instead.
Output a single valid JSON object compatible with Jarvis /api/dev/run-smoke-tests.
```
