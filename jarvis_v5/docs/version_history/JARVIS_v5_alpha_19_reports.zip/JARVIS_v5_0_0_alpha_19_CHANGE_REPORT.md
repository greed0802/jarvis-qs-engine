# Jarvis v5.0.0-alpha.19 Change Report

## Base used

v5.0.0-alpha.18.1 — Snapshot/Boundary Safety Envelope Completion, no engine

## Added

1. Contract fixture replay/golden diff utility.
2. New endpoint: `POST /api/builder/contract-fixture-replay`.
3. Stable contract normalization and volatile-field ignore list.
4. Golden fixture for Wall Types / XGETWALLAREA / m2.
5. Golden fixture for Concrete / Reinforcement / XGETCUSTOM / Reinforcement Weight / t.
6. `/api/plan` visibility for latest contract fixture replay status.
7. Alpha.19 smoke test and importable JSON pack.
8. QA runner allowlist/known-route support for fixture replay endpoint.
9. QA runner compatibility-warning cleanup for create-snapshot top-level safety fields.
10. Start scripts and next-chat handoff/test-prompt documents.

## Files added

```text
jarvis_v5/tools/builder/contract_fixture_replay.py
jarvis_v5/tests/smoke/test_alpha19_contract_fixture_replay.py
jarvis_v5/tests/packs/alpha19_contract_fixture_replay_tests.json
jarvis_v5/docs/ALPHA_19_SCOPE.md
jarvis_v5/tests/fixtures/contracts/reinforcement_xgetcustom_weight_t_zone1_head2_gf_l3_contract_v1.json
START_JARVIS_V5_ALPHA_19.bat
START_JARVIS_V5_ALPHA_19_SIMPLE_NO_RELOAD.bat
NEXT_CHAT_HANDOFF_v5_alpha_19.md
CURRENT_BACKEND_STATUS_v5_alpha_19.md
ALPHA19_EXTERNAL_AI_TEST_PROMPT.md
```

## Files changed

```text
jarvis_v5/config.py
jarvis_v5/app.py
jarvis_v5/qa_runner/test_executor.py
jarvis_v5/tests/fixtures/contracts/wall_types_xgetwallarea_zone1_head2_gf_l3_contract_v1.json
jarvis_v5/tests/smoke/test_alpha16_engine_preflight.py
jarvis_v5/tests/smoke/test_alpha17_engine_execution_lock.py
jarvis_v5/tests/smoke/test_alpha18_response_consistency.py
jarvis_v5/tests/smoke/test_alpha18_1_safety_envelope.py
jarvis_v5/tests/packs/alpha16_engine_preflight_tests.json
jarvis_v5/tests/packs/alpha17_engine_execution_lock_tests.json
jarvis_v5/tests/packs/alpha18_response_consistency_tests.json
jarvis_v5/tests/packs/alpha18_1_safety_envelope_tests.json
README.md
```

## Protected / not touched

```text
No Builder engine call
No legacy Builder import/call
No workbook reading/parsing
No formula generation
No Excel output
No Formatter
No QA Checker
No O&A
No UI redesign
No current Jarvis replacement
```
