# Jarvis v5.0.0-alpha.19 Test Report

## Tests performed

```text
PASS - python -m compileall -q jarvis_v5
PASS - PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
PASS - test_alpha19_contract_fixture_replay.py
PASS - alpha19_contract_fixture_replay_tests
PASS - alpha18_1_safety_envelope_tests
PASS - alpha18_response_consistency_tests
PASS - alpha17_engine_execution_lock_tests
PASS - alpha16_engine_preflight_tests
PASS - alpha15_review_readiness_tests
PASS - sample_external_ai_pack_valid
PASS - alpha11_contract_negative_guards
```

## Pytest result

```text
130 passed in 23.45s
```

## Pack results

```text
alpha19_contract_fixture_replay_tests: PASS - 5 passed / 0 failed
alpha18_1_safety_envelope_tests: PASS - 5 passed / 0 failed
alpha18_response_consistency_tests: PASS - 4 passed / 0 failed
alpha17_engine_execution_lock_tests: PASS - 4 passed / 0 failed
alpha16_engine_preflight_tests: PASS - 3 passed / 0 failed
alpha15_review_readiness_tests: PASS - 3 passed / 0 failed
sample_external_ai_pack_valid: PASS - 1 passed / 0 failed
alpha11_contract_negative_guards: PASS - 7 passed / 0 failed
```

## Safety aggregates

All tested pack safety aggregates stayed false:

```text
workbook_read_any_true=false
engine_called_any_true=false
excel_created_any_true=false
legacy_builder_called_any_true=false
```

## Notes

A normal full `pytest -q` run can hang in this container because of auto-loaded external pytest plugins. The clean command used for the full suite was:

```text
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
```
