# NEXT CHAT HANDOFF — Jarvis v5 Backend Rewrite

## Current version

v5.0.0-alpha.9 — Parser Conflict Guard + Setup Normalization, no engine

## Base used

v5.0.0-alpha.8 — Builder Setup Slot Parser Expansion, no engine

## Current status

Built and packaged. Needs manual Swagger testing before being marked PASS.

## What alpha.9 added

- Parser conflict guard for trade/profile conflicts.
- Function/unit mismatch clarification.
- Custom quantity/unit mismatch clarification.
- Heading ambiguity guard.
- Zone/head mismatch guard.
- Ambiguous basement range guard.
- Normalization metadata in reducer results, `/api/plan`, snapshot, adapter dry run, and review.

## Safety locks

- `workbook_read=false`
- `engine_called=false`
- `excel_created=false`

## Protected systems

No Builder engine, no Formatter, no QA Checker, no O&A, no formula generation, no workbook reading/parsing, no actual Preview/Export, no UI redesign, no current Jarvis replacement.

## Manual test priority

1. Trade conflict: `Use Wall Types and Structural Steel` should ask clarification and not mutate.
2. Function/unit conflict: `Use Count unit m2` should ask clarification and not mutate.
3. Safe setup: `Use Count unit no` should apply.
4. Heading ambiguity: two zones then `Use Head 2` should ask which zone.
5. Basement ambiguity: `Levels B2 to B5` should ask order.
6. Full safe flow from alpha.8 should still reach current snapshot + adapter dry run with all safety locks false.

## Next target after alpha.9 passes

v5.0.0-alpha.10 — Builder Engine Contract Adapter, still no Excel output.
