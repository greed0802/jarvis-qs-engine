@echo off
cd /d "%~dp0"
echo Starting Jarvis v5.0.0-alpha.9 with reload...
echo.
echo API:  http://localhost:8515/api/version
echo Docs: http://localhost:8515/docs
echo.
python -m uvicorn jarvis_v5.app:app --host 127.0.0.1 --port 8515 --reload
pause
