# Jarvis v5.0.0-alpha.9 Change Report

## Version

v5.0.0-alpha.9 — Parser Conflict Guard + Setup Normalization, no engine

## Base

v5.0.0-alpha.8 — Builder Setup Slot Parser Expansion, no engine

## Changed

- Added `jarvis_v5/parsers/conflict_guard.py`.
- Added conflict fields to reducer results.
- Added parser conflict handling to the slot reducer.
- Added parser conflict clarification resolution.
- Added safer multi-zone parsing for `Zone 1...; Zone 2...` commands.
- Added normalization/conflict metadata to snapshots, adapter dry runs, and `/api/plan`.
- Updated app/version metadata and alpha.9 BAT files.
- Added alpha.9 smoke tests.
- Added next-chat handoff files.

## Protected

No Builder engine, no workbook reading, no formula generation, no Excel output, no Formatter, no QA Checker, no O&A, no Preview/Export engine, no UI redesign, and no current Jarvis replacement.
