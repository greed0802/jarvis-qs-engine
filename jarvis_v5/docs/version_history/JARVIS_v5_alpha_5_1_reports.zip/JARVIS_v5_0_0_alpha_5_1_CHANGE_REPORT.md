# Jarvis v5.0.0-alpha.5.1 Change Report

## Version

v5.0.0-alpha.5.1 — Adapter Dry Run Freshness + Plan Display Polish

## Base used

v5.0.0-alpha.5 — Builder Adapter Dry Run, no Excel output

## Files changed

- `jarvis_v5/config.py`
- `jarvis_v5/app.py`
- `jarvis_v5/core/adapter_store.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/schemas/builder_adapter_schema.py`
- `jarvis_v5/schemas/message_schema.py`
- `jarvis_v5/tools/builder/adapter_dry_run.py`
- `README.md`

## Files added

- `jarvis_v5/tests/smoke/test_alpha51_adapter_freshness.py`
- `jarvis_v5/docs/ALPHA_5_1_SCOPE.md`
- `START_JARVIS_V5_ALPHA_5_1.bat`
- `START_JARVIS_V5_ALPHA_5_1_SIMPLE_NO_RELOAD.bat`
- `JARVIS_v5_0_0_alpha_5_1_CHANGE_REPORT.md`
- `JARVIS_v5_0_0_alpha_5_1_TEST_REPORT.md`
- `JARVIS_v5_0_0_alpha_5_1_TEST_RUN_RESULTS.txt`

## What changed

1. Added adapter freshness fields:
   - `freshness`
   - `stale_reason`
   - `updated_at`

2. Previous adapter dry-runs are marked/displayed as stale when their source snapshot becomes stale.

3. `/api/plan/{conversation_id}` now shows stale adapter dry-runs clearly:
   - `status = stale_due_to_snapshot`
   - `freshness = stale`
   - `stale_reason = source_snapshot_is_stale`

4. Review output now shows adapter freshness and action-needed guidance.

5. Router trace now includes adapter freshness metadata.

## Safety locks preserved

- `engine_called = false`
- `excel_created = false`
- Preview/Export remain stubs.

## Protected / not touched

- No Builder engine.
- No Formatter.
- No QA Checker.
- No O&A.
- No formula generation.
- No workbook reading.
- No actual Preview/Export.
- No UI redesign.
- No current Jarvis replacement.
