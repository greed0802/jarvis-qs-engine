# Jarvis v5.0.0-alpha.5.1 Test Report

## Tests performed

- Python compile check for all `jarvis_v5` modules.
- Full pytest smoke suite.
- New alpha.5.1 adapter freshness tests.

## Results

- Python compile: PASS
- Pytest smoke suite: PASS
- Total tests: 40 passed

## New tests added

1. Adapter dry-run is marked stale when its source snapshot becomes stale.
2. `/api/plan` shows stale adapter freshness/status.
3. Review shows stale adapter dry-run and action-needed guidance.
4. Stale snapshot still blocks new adapter dry-run.
5. New snapshot refreshes adapter dry-run to current.
6. No engine call and no Excel output.

## Protected regression checks

- Current snapshot adapter dry-run still passes.
- Stale snapshot adapter dry-run still blocks.
- Pending clarification still blocks adapter dry-run.
- Preview remains stubbed.
