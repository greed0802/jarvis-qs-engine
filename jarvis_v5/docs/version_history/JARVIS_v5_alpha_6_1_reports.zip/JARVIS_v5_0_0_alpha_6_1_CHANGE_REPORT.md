# Jarvis v5.0.0-alpha.6.1 — Attachment Directory Creation + Error-safe Upload Response

## Base used
v5.0.0-alpha.6 — Attachment Binding + Workbook Reference Snapshot, no workbook reading

## Fixed
- `/api/attach` no longer fails with raw 500 when `jarvis_v5/data/attachments` is missing.
- `AttachmentStore.save_upload()` recreates the attachment directory at write time.
- `api_attach()` now returns a safe JSON response if upload saving fails before binding.
- Failed attachment save leaves active task state unchanged.

## Safety locks preserved
- `workbook_read=false`
- No workbook reading/parsing
- No Builder engine
- No formula generation
- No Excel output
- No Formatter, QA, or O&A
- No UI redesign

## Files changed
- `jarvis_v5/config.py`
- `jarvis_v5/app.py`
- `jarvis_v5/core/attachment_store.py`
- `jarvis_v5/tests/smoke/test_alpha6_attachment_binding.py`
- `README.md`

## Files added
- `jarvis_v5/docs/ALPHA_6_1_SCOPE.md`
- `START_JARVIS_V5_ALPHA_6_1.bat`
- `START_JARVIS_V5_ALPHA_6_1_SIMPLE_NO_RELOAD.bat`
