@echo off
cd /d %~dp0

echo Starting Jarvis v5.0.0-alpha.7 without reload...
echo.
echo API:  http://localhost:8515/api/version
echo Docs: http://localhost:8515/docs
echo.

python -m uvicorn jarvis_v5.app:app --port 8515

echo.
echo Jarvis stopped or failed to start.
pause
