# Jarvis v5.0.0-alpha.4 Change Report

Base: v5.0.0-alpha.3.1 — Reducer Trace + Plan Review Formatting

Changed/added:
- Added `BuilderRunSnapshot` skeleton schema and validation.
- Added `SnapshotStore` with active snapshot pointer per conversation.
- Added `/api/builder/create-snapshot`.
- Added `/api/builder/snapshot/{snapshot_id}`.
- Added `/api/builder/active-snapshot/{conversation_id}`.
- Snapshot creation logs into router trace as `BUILDER_SNAPSHOT`.
- Review shows approved snapshot info when one exists.
- Preview/export remain stubbed and blocked.
- Added reliable alpha.4 BAT files using `python -m uvicorn` and pause on exit.
- Archived previous alpha.3.1 root report/start files into `docs/version_history/JARVIS_v5_alpha_3_1_reports.zip`.

Protected:
- No Builder engine, formula generation, workbook reading, Formatter, QA, O&A, UI redesign, or current Jarvis replacement.
