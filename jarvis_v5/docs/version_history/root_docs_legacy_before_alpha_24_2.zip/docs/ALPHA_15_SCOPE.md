# Jarvis v5.0.0-alpha.15 — Review/Plan UX Contract + Setup Readiness Messages, no engine

Base: v5.0.0-alpha.14 — Trade Profile Registry + Alias Normalization, no engine.

## Scope

- Add read-only readiness contract for `/api/plan` and Review responses.
- Summarize setup completeness, pending clarification, blockers, next safe actions, snapshot/adapter/contract status, preview/export stub status, and no-engine safety locks.
- Make Review messages clearer while preserving previous debug phrases used by smoke tests.
- Carry trade registry and normalization status into readable Review output.
- Allow `POST /api/builder/engine-boundary-audit` in imported QA runner packs.
- Update valid_for_future_engine assertion guidance to use nested paths.

## Protected

- No Builder engine.
- No workbook reading/parsing.
- No formula generation.
- No Excel output.
- No Formatter.
- No QA logic beyond dev test runner allowlist cleanup.
- No O&A.
- No UI redesign.
- No current Jarvis replacement.

## Safety Locks

- workbook_read=false
- engine_called=false
- excel_created=false
- contract_only=true
- legacy_builder_called=false
