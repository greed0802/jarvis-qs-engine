# Jarvis v5.0.0-alpha.5 Change Report

## Version
v5.0.0-alpha.5 — Builder Adapter Dry Run, no Excel output

## Base
v5.0.0-alpha.4.1 — Snapshot Invalidation + Trace Polish

## Added
1. Builder adapter dry-run schema.
2. Builder adapter dry-run endpoint: `POST /api/builder/adapter-dry-run`.
3. Adapter dry-run validation split into dry-run readiness and future-engine readiness.
4. Adapter dry-run result persistence on active task and adapter store.
5. Adapter dry-run summary in `/api/plan/{conversation_id}`.
6. Adapter dry-run summary in Review message.
7. Adapter metadata in router trace.
8. Tests for current snapshot dry run, stale snapshot block, pending clarification block, and Preview stub safety.

## Safety
- `engine_called=false` is hard-coded.
- `excel_created=false` is hard-coded.
- No workbook is read.
- No Builder engine is imported or called.
- Preview/Export remain safe stubs.

## Protected
No Builder engine, Formatter, QA, O&A, formula generation, workbook reading, UI redesign, or current Jarvis replacement.
