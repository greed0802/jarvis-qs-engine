Test Jarvis v5.0.0-alpha.22.2D for no-engine safety.
Focus on:
- No-active-task language gate ownership
- feedback vs writing-help ownership
- conflict_guard evidence in reducer_result.conflicts
- multi-clause active Builder setup messages
- raw/canonical conflict preservation
- snapshot/adapter/contract safety locks
Do not expect Builder engine, workbook parsing, Excel output, Formatter, QA Checker, or O&A execution.
