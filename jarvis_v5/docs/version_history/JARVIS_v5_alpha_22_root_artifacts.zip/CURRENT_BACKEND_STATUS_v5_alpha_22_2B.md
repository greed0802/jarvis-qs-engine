# Current Backend Status — v5.0.0-alpha.22.2B

Current package: `v5.0.0-alpha.22.2B — Limited-Control Router Confidence Engine, no engine`.

Accepted behavior:

- Confidence engine may take limited control only when no active task, no pending clarification, and no attachment context exists.
- Limited control applies only to no-active-task general fallback/choose-tool paths.
- Active Builder reducer/parser grammar is unchanged.
- Pending clarification, attachments, snapshot, adapter, contract, preflight, and execution remain controlled by existing runtime guards.

Safety boundary remains locked:

- `workbook_read=false`
- `engine_called=false`
- `excel_created=false`
- `contract_only=true`
- `legacy_builder_called=false`

Next recommended target:

`v5.0.0-alpha.22.2C — Active Builder Natural Setup Grammar, no engine`
