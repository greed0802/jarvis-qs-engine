# Test Report — v5.0.0-alpha.22.2F

- Compile: PASS
- Pytest: PASS, 191 passed
- Focused alpha22_2f pack: PASS
- Retained QA packs: PASS
- Engineering 4000 suite: 3988/4000
- Safety aggregates: all false

Remaining 12 failures are deliberate clarification-safe behavior in active setup edit packs.
