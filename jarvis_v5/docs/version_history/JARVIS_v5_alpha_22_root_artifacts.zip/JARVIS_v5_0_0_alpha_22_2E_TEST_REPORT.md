# Jarvis v5.0.0-alpha.22.2E Test Report

Compile: PASS
Pytest: PASS — 186 passed
Focused 2E pack: PASS — 5 passed / 0 failed
Retained QA packs: PASS
High-priority weakness packs: 699 / 700 raw
Full 3000 weakness suite: 2644 / 3000

Safety aggregates:
- workbook_read_any_true=false
- engine_called_any_true=false
- excel_created_any_true=false
- legacy_builder_called_any_true=false

The one high-priority raw miss is an old version assertion expecting v5.0.0-alpha.22.2C while the current package correctly reports v5.0.0-alpha.22.2E.
