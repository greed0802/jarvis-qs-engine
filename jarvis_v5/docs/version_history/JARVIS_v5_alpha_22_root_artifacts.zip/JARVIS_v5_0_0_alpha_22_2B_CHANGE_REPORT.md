# Jarvis v5.0.0-alpha.22.2B Change Report

## Version

`v5.0.0-alpha.22.2B — Limited-Control Router Confidence Engine, no engine`

## Base used

`v5.0.0-alpha.22.2A — Router Confidence Engine Shadow Mode + No-Task Plan Safety, no engine`

## What changed

1. Added limited-control eligibility to the router confidence engine.
2. Allowed confidence control only when no active task, no pending clarification, and no attachment context exists.
3. Allowed control only for no-active-task fallback/choose-tool paths:
   - general writing negative guards
   - generic choose-tool ambiguity
   - soft Builder-start shell creation
   - casual estimate/schedule/value/cost negative guards
4. Added explicit `mode=limited_control` and `control_taken=true` metadata only when control is taken.
5. Expanded narrow no-active-task confidence patterns for writing, casual guards, and soft Builder shell starts.
6. Added alpha.22.2B smoke tests and JSON QA pack.

## Files changed

- `jarvis_v5/config.py`
- `jarvis_v5/router/router_confidence_engine.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/router/qs_intent_aliases.py`
- `jarvis_v5/tests/smoke/test_alpha22_2a_router_confidence_shadow.py`
- `jarvis_v5/tests/packs/alpha22_2a_router_confidence_shadow_tests.json`
- existing retained tests/packs version lock updates
- `README.md`

## Files added

- `jarvis_v5/tests/smoke/test_alpha22_2b_limited_control_router.py`
- `jarvis_v5/tests/packs/alpha22_2b_limited_control_router_tests.json`
- `jarvis_v5/docs/ALPHA_22_2B_SCOPE.md`
- `START_JARVIS_V5_ALPHA_22_2B.bat`
- `START_JARVIS_V5_ALPHA_22_2B_SIMPLE_NO_RELOAD.bat`
- `CURRENT_BACKEND_STATUS_v5_alpha_22_2B.md`
- `NEXT_CHAT_HANDOFF_v5_alpha_22_2B.md`
- `ALPHA22_2B_EXTERNAL_AI_TEST_PROMPT.md`
- `JARVIS_v5_0_0_alpha_22_2B_CHANGE_REPORT.md`
- `JARVIS_v5_0_0_alpha_22_2B_TEST_REPORT.md`
- `JARVIS_v5_0_0_alpha_22_2B_TEST_RUN_RESULTS.txt`

## Protected / not touched

- No Builder engine
- No legacy Builder import/call
- No workbook reading/parsing
- No formula generation
- No Excel output
- No Formatter
- No QA Checker
- No O&A
- No active Builder reducer/parser grammar changes
- No pending clarification resolver changes
- No attachment binding changes
- No snapshot/adapter/contract/preflight/execution changes
- No UI redesign
- No current Jarvis replacement
