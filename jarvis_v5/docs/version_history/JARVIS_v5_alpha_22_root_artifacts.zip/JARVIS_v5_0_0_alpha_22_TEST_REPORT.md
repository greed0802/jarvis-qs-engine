# Jarvis v5.0.0-alpha.22 Test Report

## Compile and test

- PASS — `python -m compileall -q jarvis_v5`
- PASS — `pytest -q` through `pytest.main` with plugin autoload disabled
- PASS — alpha.22 smoke tests
- PASS — alpha.22 JSON QA pack
- PASS — retained no-engine regression packs

## Pytest result

`148 passed`

## QA packs

- `alpha22_qs_intent_alias_router_tests`: PASS — 8 passed / 0 failed
- `alpha21_function_unit_compatibility_tests`: PASS — 5 passed / 0 failed
- `alpha20_deep_weak_point_boundary_tests`: PASS — 2 passed / 0 failed
- `alpha20_legacy_import_boundary_audit_tests`: PASS — 4 passed / 0 failed
- `alpha19_contract_fixture_replay_tests`: PASS — 5 passed / 0 failed
- `alpha18_1_safety_envelope_tests`: PASS — 5 passed / 0 failed
- `alpha11_contract_negative_guards`: PASS — 7 passed / 0 failed

## Safety aggregate results

All QA packs preserved:

- `workbook_read_any_true=false`
- `engine_called_any_true=false`
- `excel_created_any_true=false`
- `legacy_builder_called_any_true=false`

## Notes

The full pytest command reached completion and reported `148 passed`. It was run using a Python wrapper with `os._exit()` after `pytest.main()` to avoid the local TestClient teardown hang observed when invoking pytest directly in this container session.
