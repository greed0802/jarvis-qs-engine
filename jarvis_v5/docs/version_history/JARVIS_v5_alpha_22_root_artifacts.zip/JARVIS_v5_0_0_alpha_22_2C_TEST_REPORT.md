# Jarvis v5.0.0-alpha.22.2C Test Report

## Fast checks

- PASS — `python -m compileall -q jarvis_v5`
- PASS — FastAPI import/version check
- PASS — `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q`

Pytest result:

```text
176 passed
```

## Focused tests

- PASS — `test_alpha22_2c_route_ownership_and_setup_normalization.py`
- PASS — `alpha22_2c_route_ownership_and_setup_normalization_tests`

## Retained QA packs

- PASS — `alpha22_2b_limited_control_router_tests`
- PASS — `alpha22_2a_router_confidence_shadow_tests`
- PASS — `alpha22_1_no_fallback_router_tightening_tests`
- PASS — `alpha22_qs_intent_alias_router_tests`
- PASS — `alpha21_function_unit_compatibility_tests`
- PASS — `alpha20_deep_weak_point_boundary_tests`
- PASS — `alpha20_legacy_import_boundary_audit_tests`
- PASS — `alpha19_contract_fixture_replay_tests`
- PASS — `alpha18_1_safety_envelope_tests`
- PASS — `alpha11_contract_negative_guards`

## Split 1000-pack result

Pack:

```text
jarvis_v5_alpha22_2B_limited_control_language_1000_tests
```

Result:

```text
PASS — 1000 passed / 0 failed
```

Safety aggregates:

```text
workbook_read_any_true=false
engine_called_any_true=false
excel_created_any_true=false
legacy_builder_called_any_true=false
```

## Note

An extra exploratory run against older large packs was started in one combined command and timed out. It was not used as acceptance evidence. The approved 2C acceptance pack was run split by pack file and completed without timeout.
