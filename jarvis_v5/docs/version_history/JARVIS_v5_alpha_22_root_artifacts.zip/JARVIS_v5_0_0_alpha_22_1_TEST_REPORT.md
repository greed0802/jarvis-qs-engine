# Jarvis v5.0.0-alpha.22.1 Test Report

## Compile and pytest

- PASS — `python -m compileall -q jarvis_v5`
- PASS — focused alpha.22.1/alpha.22/registry smoke subset: `19 passed`
- PASS — full pytest smoke suite: `154 passed`

## QA packs

- PASS — `alpha22_1_no_fallback_router_tightening_tests`: 5 passed / 0 failed
- PASS — `alpha22_qs_intent_alias_router_tests`: 8 passed / 0 failed
- PASS — `alpha21_function_unit_compatibility_tests`: 5 passed / 0 failed
- PASS — `alpha20_deep_weak_point_boundary_tests`: 2 passed / 0 failed
- PASS — `alpha20_legacy_import_boundary_audit_tests`: 4 passed / 0 failed
- PASS — `alpha19_contract_fixture_replay_tests`: 5 passed / 0 failed
- PASS — `alpha18_1_safety_envelope_tests`: 5 passed / 0 failed
- PASS — `alpha11_contract_negative_guards`: 7 passed / 0 failed

## Safety aggregate results

All QA packs kept:

- `workbook_read_any_true=false`
- `engine_called_any_true=false`
- `excel_created_any_true=false`
- `legacy_builder_called_any_true=false`

## External 1000-test check

A normalized copy of the uploaded alpha.22 senior QS pack was partially rerun with version assertions updated to alpha.22.1. Packs 01–07 passed before the long external run was stopped/timed out. Full 1000-pack completion was not claimed.

Confirmed passed before timeout:

- 01_alpha22_qs_intent_alias_router: PASS 50/50
- 02_alpha22_negative_alias_guards: PASS 50/50
- 03_alpha22_no_fallback_clarification_guard: PASS 50/50
- 04_active_builder_task_priority: PASS 50/50
- 05_valid_builder_contract_flows_no_engine: PASS 50/50
- 06_valid_builder_contract_flows_regional: PASS 50/50
- 07_function_unit_negative_guards: PASS 50/50

Safety stayed false in the completed external packs.
