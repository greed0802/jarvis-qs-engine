# Jarvis v5.0.0-alpha.22.2A Change Report

## Base

v5.0.0-alpha.22.1 — No-Fallback Router Tightening + Trade Ambiguity Guard, no engine.

## Added

- Read-only Router Confidence Engine shadow helper.
- `confidence_engine` metadata in `/api/chat` responses.
- No-active-task and conversation-not-found `/api/plan` safety/readiness envelope.
- Alpha.22.2A smoke tests and JSON QA pack.

## Files added

- `jarvis_v5/router/router_confidence_engine.py`
- `jarvis_v5/tests/smoke/test_alpha22_2a_router_confidence_shadow.py`
- `jarvis_v5/tests/packs/alpha22_2a_router_confidence_shadow_tests.json`
- `jarvis_v5/docs/ALPHA_22_2A_SCOPE.md`
- `START_JARVIS_V5_ALPHA_22_2A.bat`
- `START_JARVIS_V5_ALPHA_22_2A_SIMPLE_NO_RELOAD.bat`

## Files changed

- `jarvis_v5/config.py`
- `jarvis_v5/app.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/schemas/message_schema.py`
- version assertions in retained tests/packs
- `README.md`

## Protected systems not touched

- No Builder engine
- No legacy Builder import/call
- No workbook reading/parsing
- No formula generation
- No Excel output
- No Formatter
- No QA Checker
- No O&A
- No UI redesign
