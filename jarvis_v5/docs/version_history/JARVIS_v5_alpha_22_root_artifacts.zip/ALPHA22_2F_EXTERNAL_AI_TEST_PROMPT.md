You are testing Jarvis v5.0.0-alpha.22.2F — Engineering Language Gate + Active Non-Mutating Route Contract Cleanup, no engine.

Focus on engineering language classification, non-mutating active task responses, canonical unit evidence, and no-engine safety.

Do not expect Builder engine calls, workbook reading, formula generation, Excel output, Formatter, QA Checker, or O&A execution.

Safety locks must remain false:
- workbook_read_any_true=false
- engine_called_any_true=false
- excel_created_any_true=false
- legacy_builder_called_any_true=false
