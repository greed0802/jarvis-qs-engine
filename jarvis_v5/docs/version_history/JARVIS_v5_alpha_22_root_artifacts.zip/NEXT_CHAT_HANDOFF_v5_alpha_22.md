# Next Chat Handoff — Jarvis v5 alpha.22

Current accepted build candidate:

`v5.0.0-alpha.22 — QS Intent Alias Router + No-Fallback Clarification Guard, no engine`

Base used:

`v5.0.0-alpha.21 — Function/Unit Compatibility Guard, no engine`

What alpha.22 added:

1. QS Builder-start alias detector.
2. Regional BOQ terminology support.
3. Negative guards for casual schedule/estimate/value/cost/format phrases.
4. Active task priority protection.
5. No-fallback clarification/choose-tool guard for ambiguous tool-like phrases.
6. Route confidence metadata in `/api/chat`.
7. Alpha.22 smoke and JSON QA tests.

Tests:

- Pytest: 148 passed.
- Alpha.22 QA pack: PASS, 8/8.
- Retained regression packs: PASS.
- Safety aggregates stayed false.

Protected systems not touched:

- Builder engine.
- Legacy Builder import/call.
- Workbook reading/parsing.
- Formula generation.
- Excel output.
- Formatter.
- QA Checker.
- O&A.
- UI redesign.

Recommended next target:

`v5.0.0-alpha.24 — Router Confidence Matrix + Tool Intent Contract Audit, no engine`

Purpose: make routing confidence measurable across Builder/Formatter/QA/document-reader intent classes before connecting any real engine.
