# External AI Test Prompt — Jarvis v5.0.0-alpha.22.1

Create JSON QA tests for Jarvis v5.0.0-alpha.22.1 focused only on no-engine router behavior.

Must preserve:

- workbook_read_any_true=false
- engine_called_any_true=false
- excel_created_any_true=false
- legacy_builder_called_any_true=false

Focus areas:

1. Generic tool-like phrases route to choose_tool, not general_stub.
2. Writing-format phrases route to general writing help, not Formatter.
3. Ambiguous trade choices like Carpet or Tiling require clarification.
4. Regional QS aliases such as trade measure schedule start Builder shell safely.
5. Existing negative guards such as Schedule a meeting and What is a Schedule of Values do not start Builder.

Do not expect Builder engine, workbook reading, formula generation, Excel output, Formatter execution, QA Checker execution, O&A, document reading, or standards knowledge.
