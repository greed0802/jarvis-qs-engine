# Next Chat Handoff — v5.0.0-alpha.22.2B

Current accepted package:

`v5.0.0-alpha.22.2B — Limited-Control Router Confidence Engine, no engine`

Base used:

`v5.0.0-alpha.22.2A — Router Confidence Engine Shadow Mode + No-Task Plan Safety, no engine`

What 22.2B added:

1. Limited-control gate for the confidence engine.
2. Control only for no-active-task fallback/choose-tool paths.
3. Supported lanes:
   - general writing negative guards
   - generic choose-tool ambiguity
   - soft Builder-start shell creation
   - casual estimate/schedule/value/cost negative guards
4. Explicit `mode=limited_control` and `control_taken=true` only when control is actually taken.
5. Protected contexts keep `control_taken=false`.

What 22.2B did not change:

- active Builder reducer/parser grammar
- pending clarification resolver
- attachment binding
- snapshot/adapter/contract/preflight/execution
- Builder engine / workbook reading / formulas / Excel
- Formatter / QA / O&A

Tests:

- Pytest full smoke: `170 passed`
- Retained QA packs: PASS
- External senior 1000 raw: `834/1000`
- External ambiguous 1000 raw: `795/1000`

Next recommended dry run:

`v5.0.0-alpha.22.2C — Active Builder Natural Setup Grammar, no engine`

Potential 22.2C scope:

- Understand active-task natural grammar like “The unit should be m2.”
- Understand “For now, Zone 1 is Old and New.”
- Understand “Please put Zone 1 under Head 2.”
- Keep no-engine safety locks.
