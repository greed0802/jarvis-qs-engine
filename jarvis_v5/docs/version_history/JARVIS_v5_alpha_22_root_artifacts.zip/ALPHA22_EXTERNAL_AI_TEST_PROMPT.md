# Alpha.22 External AI Test Pack Prompt

Create an importable JSON QA pack for Jarvis v5.0.0-alpha.22.

Focus:

- QS Builder-start aliases.
- Regional BOQ terminology.
- Negative guards for casual schedule/estimate/value/cost/format phrases.
- Active task preservation.
- Ambiguous phrases route to clarification/choose-tool, not general fallback.
- No-engine safety locks remain false.

Do not expect:

- Builder engine call.
- Workbook reading.
- Formula generation.
- Excel output.
- Formatter execution.
- QA execution.

Required safety aggregate:

- workbook_read_any_true=false
- engine_called_any_true=false
- excel_created_any_true=false
- legacy_builder_called_any_true=false
