# External AI Test Prompt — Jarvis v5.0.0-alpha.22.2A

Create JSON QA tests for Jarvis v5.0.0-alpha.22.2A focused on Router Confidence Engine shadow mode.

Rules:
- No Builder engine
- No workbook reading
- No Excel output
- No Formatter / QA / O&A execution
- Assert `confidence_engine.control_taken=false`
- Assert `actual_route` and `would_route` are visible
- Assert no-active-task `/api/plan` has `readiness.safety` all false
