# Jarvis v5.0.0-alpha.22.2A Test Report

## Local smoke tests

- PASS — `python -m compileall -q jarvis_v5`
- PASS — full pytest smoke suite: `160 passed`

## Retained JSON packs

- PASS — `alpha22_2a_router_confidence_shadow_tests`: 5 passed / 0 failed
- PASS — `alpha22_1_no_fallback_router_tightening_tests`: 5 passed / 0 failed
- PASS — `alpha22_qs_intent_alias_router_tests`: 8 passed / 0 failed
- PASS — `alpha21_function_unit_compatibility_tests`: 5 passed / 0 failed
- PASS — `alpha20_deep_weak_point_boundary_tests`: 2 passed / 0 failed
- PASS — `alpha20_legacy_import_boundary_audit_tests`: 4 passed / 0 failed
- PASS — `alpha19_contract_fixture_replay_tests`: 5 passed / 0 failed
- PASS — `alpha18_1_safety_envelope_tests`: 5 passed / 0 failed
- PASS — `alpha11_contract_negative_guards`: 7 passed / 0 failed

## External 1000-pack reruns

- Senior QS 1000-pack normalized to alpha.22.2A: 802 passed / 198 failed
- Ambiguous human grammar 1000-pack normalized to alpha.22.2A: 670 passed / 330 failed

Failures remain mostly future-scope modules or route-control behavior that shadow mode intentionally does not change.

## Safety aggregates

All retained and external packs kept:

- `workbook_read_any_true=false`
- `engine_called_any_true=false`
- `excel_created_any_true=false`
- `legacy_builder_called_any_true=false`
