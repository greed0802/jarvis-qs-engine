# Jarvis v5.0.0-alpha.22 Change Report

## Base

v5.0.0-alpha.21 — Function/Unit Compatibility Guard, no engine

## Scope fired

QS Intent Alias Router + No-Fallback Clarification Guard, no engine.

## Files added

- `jarvis_v5/router/qs_intent_aliases.py`
- `jarvis_v5/tests/smoke/test_alpha22_qs_intent_alias_router.py`
- `jarvis_v5/tests/packs/alpha22_qs_intent_alias_router_tests.json`
- `jarvis_v5/docs/ALPHA_22_SCOPE.md`
- `START_JARVIS_V5_ALPHA_22.bat`
- `START_JARVIS_V5_ALPHA_22_SIMPLE_NO_RELOAD.bat`

## Files changed

- `jarvis_v5/config.py`
- `jarvis_v5/app.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/router/intent_classifier.py`
- `jarvis_v5/schemas/message_schema.py`
- `jarvis_v5/qa_runner/test_executor.py`
- `jarvis_v5/tests/*` version expectations
- `README.md`

## What changed

- Added controlled QS Builder-start aliases.
- Added regional QS terminology recognition.
- Added negative guards for casual schedule/estimate/value/cost/format-style phrases.
- Preserved active Builder task priority when a new QS command is typed during an active task.
- Routed ambiguous active-task phrases to clarification/choose-tool style responses, not general fallback.
- Added route confidence evidence to `/api/chat` responses.

## Not touched

- Builder engine.
- Legacy Builder import/call.
- Workbook reading/parsing.
- Formula generation.
- Excel output.
- Formatter execution.
- QA Checker execution.
- O&A.
- UI redesign.
