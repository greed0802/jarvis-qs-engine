# External AI Test Prompt — Jarvis v5.0.0-alpha.22.2B

Create JSON QA tests for Jarvis v5.0.0-alpha.22.2B focused only on Limited-Control Router Confidence Engine behavior.

Allowed scope:

- no-active-task general writing negative guards
- no-active-task generic choose-tool ambiguity
- no-active-task soft Builder-start shell creation
- no-active-task casual estimate/schedule/value/cost negative guards

Do not test as valid scope:

- active Builder natural setup grammar
- Builder reducer/parser mutation
- pending clarification resolver changes
- attachment binding changes
- snapshot/adapter/contract/preflight/execution changes
- Builder engine, workbook reading, formulas, Excel output, Formatter, QA, or O&A execution

Required safety:

- workbook_read_any_true=false
- engine_called_any_true=false
- excel_created_any_true=false
- legacy_builder_called_any_true=false
