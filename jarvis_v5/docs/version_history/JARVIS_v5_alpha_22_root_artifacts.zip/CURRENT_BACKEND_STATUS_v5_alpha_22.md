# Current Backend Status — v5.0.0-alpha.22

Accepted package candidate:

`v5.0.0-alpha.22 — QS Intent Alias Router + No-Fallback Clarification Guard, no engine`

Current safety boundary:

- No Builder engine call.
- No legacy Builder import/call.
- No workbook reading/parsing.
- No formula generation.
- No Excel output.
- No Formatter execution.
- No QA Checker execution.
- No O&A.

New alpha.22 capability:

- Regional QS terms can start a Builder shell safely.
- Ambiguous tool-like phrases route to clarification/choose-tool instead of general fallback.
- Active Builder tasks are preserved if a new QS command appears during the active task.
- `/api/chat` exposes route confidence evidence.

Stable v4 rollback remains:

`v4.5.1.26.3.4 — Transcript Attachment Hygiene + Legacy Zone Value Sync`
