Test Jarvis v5.0.0-alpha.22.2E.
Focus on active Builder non-mutating language, /api/plan response shape, active setup slot reducer ownership, and no-engine safety.
Do not expect Builder/Formatter/QA/O&A execution.
Required safety locks: workbook_read=false, engine_called=false, excel_created=false, legacy_builder_called=false.
