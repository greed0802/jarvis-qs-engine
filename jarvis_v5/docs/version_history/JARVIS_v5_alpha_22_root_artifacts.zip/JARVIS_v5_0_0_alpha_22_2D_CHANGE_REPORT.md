# Change Report — v5.0.0-alpha.22.2D

Base: v5.0.0-alpha.22.2C.

## Changed
- jarvis_v5/config.py
- jarvis_v5/router/main_router.py
- jarvis_v5/router/feedback_router.py
- jarvis_v5/router/intent_classifier.py
- jarvis_v5/router/no_active_task_language_gate.py
- jarvis_v5/reducers/setup_text_normalizer.py
- jarvis_v5/reducers/slot_reducer.py
- jarvis_v5/schemas/reducer_schema.py
- jarvis_v5/parsers/trade_parser.py
- jarvis_v5/parsers/conflict_guard.py
- jarvis_v5/tools/builder/function_unit_compatibility.py
- jarvis_v5/tests/smoke/test_alpha22_2d_high_priority_ownership_repair.py
- jarvis_v5/tests/packs/alpha22_2d_high_priority_ownership_repair_tests.json

## Added
- jarvis_v5/docs/ALPHA_22_2D_SCOPE.md
- START_JARVIS_V5_ALPHA_22_2D.bat
- START_JARVIS_V5_ALPHA_22_2D_SIMPLE_NO_RELOAD.bat
- CURRENT_BACKEND_STATUS_v5_alpha_22_2D.md
- NEXT_CHAT_HANDOFF_v5_alpha_22_2D.md
- ALPHA22_2D_EXTERNAL_AI_TEST_PROMPT.md

## Fixed
- no-active-task writing/help no longer stolen by feedback routing
- general QS-help phrases handled by NoActiveTaskLanguageGate with fallback_used=false
- conflict guard evidence exposed as reducer_result.conflicts
- multi-clause setup text can set trade/function/unit/zones/headings/levels together
- unit aliases sqm/square metres normalize to m2 where appropriate
- explicit reinforcement weight/t setup can proceed without unnecessary registry clarification

## Not touched
Builder engine, legacy Builder call, workbook reading/parsing, formula generation, Excel output, Formatter, QA, O&A, snapshot/adapter/contract/preflight/execution logic, UI redesign.
