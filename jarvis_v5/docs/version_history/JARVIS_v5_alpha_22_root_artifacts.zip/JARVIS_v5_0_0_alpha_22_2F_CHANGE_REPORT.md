# Change Report — v5.0.0-alpha.22.2F

## Base

v5.0.0-alpha.22.2E

## Changed

- Added EngineeringLanguageGate classifier.
- Integrated engineering classifier into ActiveTaskNonMutatingLanguageGate and NoActiveTaskLanguageGate.
- Unified active non-mutating public route as `active_task_non_mutating_language`.
- Added canonical unit evidence in reducer normalization.
- Improved engineering choose-tool ambiguity clarification.
- Expanded engineering term/unit families.

## Protected

No Builder engine, workbook reading/parsing, formula generation, Excel output, Formatter, QA, O&A, snapshot, adapter, contract, preflight, execution, or UI redesign.
