# Jarvis v5.0.0-alpha.22.1 Change Report

## Version

v5.0.0-alpha.22.1 — No-Fallback Router Tightening + Trade Ambiguity Guard, no engine.

## Base used

v5.0.0-alpha.22 — QS Intent Alias Router + No-Fallback Clarification Guard, no engine.

## Fixed

1. `Compare`, `Check`, `Create`, `Run it`, and `Start the tool` now route to `choose_tool` instead of `general_stub`.
2. `Format this sentence` and `Format this chat reply only` now route to general writing help with `fallback_used=false`, not Formatter.
3. `Use Carpet or Tiling` now opens a trade ambiguity clarification instead of silently choosing Carpet.
4. Added controlled QS Builder-start alias for `trade measure schedule`.
5. Added `general_chat` as a known QA route.

## Files added

- `jarvis_v5/tests/smoke/test_alpha22_1_no_fallback_router_tightening.py`
- `jarvis_v5/tests/packs/alpha22_1_no_fallback_router_tightening_tests.json`
- `jarvis_v5/docs/ALPHA_22_1_SCOPE.md`
- `START_JARVIS_V5_ALPHA_22_1.bat`
- `START_JARVIS_V5_ALPHA_22_1_SIMPLE_NO_RELOAD.bat`
- `JARVIS_v5_0_0_alpha_22_1_CHANGE_REPORT.md`
- `JARVIS_v5_0_0_alpha_22_1_TEST_REPORT.md`
- `JARVIS_v5_0_0_alpha_22_1_TEST_RUN_RESULTS.txt`
- `CURRENT_BACKEND_STATUS_v5_alpha_22_1.md`
- `NEXT_CHAT_HANDOFF_v5_alpha_22_1.md`
- `ALPHA22_1_EXTERNAL_AI_TEST_PROMPT.md`

## Files changed

- `jarvis_v5/config.py`
- `jarvis_v5/router/qs_intent_aliases.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/parsers/conflict_guard.py`
- `jarvis_v5/qa_runner/test_executor.py`
- `jarvis_v5/tests/smoke/*` version assertions updated to alpha.22.1
- `jarvis_v5/tests/packs/*` version assertions updated to alpha.22.1
- `README.md`

## Protected systems not touched

- Builder engine.
- Legacy Builder import/call.
- Workbook reading/parsing.
- CostX formula generation.
- Excel output.
- Formatter execution.
- QA Checker execution.
- O&A.
- UI redesign.
- Current Jarvis replacement.
