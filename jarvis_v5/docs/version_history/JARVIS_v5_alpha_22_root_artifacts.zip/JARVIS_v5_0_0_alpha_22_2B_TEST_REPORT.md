# Jarvis v5.0.0-alpha.22.2B Test Report

## Local tests

- `python -m compileall -q jarvis_v5` — PASS
- `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q` — PASS
- Pytest result: `170 passed`

## Focused alpha.22.2B smoke

- `test_alpha22_2b_limited_control_router.py` — PASS
- Result: `10 passed`

## QA packs run

- `alpha22_2b_limited_control_router_tests` — PASS, 6 passed / 0 failed
- `alpha22_2a_router_confidence_shadow_tests` — PASS, 5 passed / 0 failed
- `alpha22_1_no_fallback_router_tightening_tests` — PASS, 5 passed / 0 failed
- `alpha22_qs_intent_alias_router_tests` — PASS, 8 passed / 0 failed
- `alpha21_function_unit_compatibility_tests` — PASS, 5 passed / 0 failed
- `alpha20_deep_weak_point_boundary_tests` — PASS, 2 passed / 0 failed
- `alpha20_legacy_import_boundary_audit_tests` — PASS, 4 passed / 0 failed
- `alpha19_contract_fixture_replay_tests` — PASS, 5 passed / 0 failed
- `alpha18_1_safety_envelope_tests` — PASS, 5 passed / 0 failed
- `alpha11_contract_negative_guards` — PASS, 7 passed / 0 failed

All retained QA pack safety aggregates remained false:

- `workbook_read_any_true=false`
- `engine_called_any_true=false`
- `excel_created_any_true=false`
- `legacy_builder_called_any_true=false`

## External 1000-pack dry checks

Raw external packs were run directly from the uploaded test ZIPs without normalizing version assertions.

- Senior QS 1000-pack: `834 passed / 166 failed`
- Ambiguous human grammar 1000-pack: `795 passed / 205 failed`

Notes:

- Senior pack includes one raw version assertion still expecting `v5.0.0-alpha.22`, so functional score is effectively `835/1000` if that compatibility artifact is ignored.
- Remaining ambiguous-pack failures are mostly future scope or alpha.22.2C active Builder natural setup grammar, not alpha.22.2B no-active-task confidence control.

## Safety verdict

PASS. Alpha.22.2B stayed no-engine:

- no workbook read
- no Builder engine call
- no legacy Builder call
- no formula generation
- no Excel output
- no Formatter / QA / O&A execution
