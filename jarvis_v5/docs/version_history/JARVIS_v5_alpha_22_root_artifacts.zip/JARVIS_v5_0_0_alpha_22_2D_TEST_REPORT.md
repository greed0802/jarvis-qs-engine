# Test Report — v5.0.0-alpha.22.2D

## Core tests
- python -m compileall -q jarvis_v5: PASS
- PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q: PASS, 181 passed

## Focused smoke
- test_alpha22_2d_high_priority_ownership_repair.py: PASS, 5 passed

## Retained QA packs
All retained critical QA packs passed with safety aggregates false.

## Weakness 3000 pack
- High-priority packs: 699/700 raw. The single failure is the external pack expecting v5.0.0-alpha.22.2C while this package correctly reports v5.0.0-alpha.22.2D.
- All 60 weakness packs: 2614/3000 raw.
- Safety across all weakness packs: workbook_read_any_true=false, engine_called_any_true=false, excel_created_any_true=false, legacy_builder_called_any_true=false.

## Remaining failures
Remaining failures are concentrated in future-tool/advisory/minimal-pair packs expecting planned modules or route choices outside 22.2D no-engine scope.
