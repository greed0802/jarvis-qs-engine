# Next Chat Handoff — Jarvis v5.0.0-alpha.22.1

## Current accepted package

v5.0.0-alpha.22.1 — No-Fallback Router Tightening + Trade Ambiguity Guard, no engine.

## Base used

v5.0.0-alpha.22 — QS Intent Alias Router + No-Fallback Clarification Guard, no engine.

## What alpha.22.1 fixed

1. `Compare`, `Check`, `Create`, `Run it`, and `Start the tool` route to `choose_tool`, not `general_stub`.
2. `Format this sentence` / `Format this chat reply only` route to general writing help, not Formatter and not fallback.
3. `Use Carpet or Tiling` opens a trade ambiguity clarification and does not silently mutate to Carpet.
4. `trade measure schedule` starts a safe Builder shell.

## Tests

- Pytest: 154 passed.
- Key QA packs: all passed.
- Safety aggregates stayed false.

## Carry-forward risks

- The full external 1000-test pack was not completed after alpha.22.1 because later packs are long and include future-tool expectations.
- Future packs for O&A, Formatter, QA Checker, consultant reports, standards, and senior QS advisory should remain expected-fail/roadmap until those modules exist.

## Protected systems

Do not touch unless explicitly approved:

- Builder engine.
- Legacy Builder import/call.
- Workbook reading/parsing.
- Formula generation.
- Excel output.
- Formatter execution.
- QA Checker execution.
- O&A.
- UI redesign.
