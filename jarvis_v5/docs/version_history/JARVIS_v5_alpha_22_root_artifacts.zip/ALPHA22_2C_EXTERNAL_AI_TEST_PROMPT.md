Create importable Jarvis v5 JSON tests for:

Target version: v5.0.0-alpha.22.2C

Focus:
- no-active-task language gate ownership
- writing/casual/tool/soft Builder routing
- active Builder setup grammar normalization
- conflict preservation for function/unit mismatches
- confidence_engine.control_taken=false for active task, pending clarification, attachment, and Builder control endpoint contexts

Do not expect:
- Builder engine calls
- workbook reading/parsing
- formula generation
- Excel output
- Formatter execution
- QA Checker execution
- O&A execution
- UI actions

Safety must remain:
- workbook_read_any_true=false
- engine_called_any_true=false
- excel_created_any_true=false
- legacy_builder_called_any_true=false
