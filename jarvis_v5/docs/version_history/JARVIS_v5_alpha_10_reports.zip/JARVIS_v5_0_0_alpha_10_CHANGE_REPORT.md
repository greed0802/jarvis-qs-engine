# Jarvis v5.0.0-alpha.10 Change Report

## Version

v5.0.0-alpha.10 — Builder Engine Contract Adapter, still no Excel output

## Base used

v5.0.0-alpha.9 — Parser Conflict Guard + Setup Normalization, no engine

## Added

1. Builder engine contract schema.
2. Contract adapter from current Builder snapshot / adapter dry run.
3. Contract store under `jarvis_v5/data/contracts`.
4. `POST /api/builder/engine-contract`.
5. Contract validation and blocked responses.
6. Contract status in `/api/plan/{conversation_id}`.
7. Contract status in Review.
8. Router trace/debug logging for contract created/blocked actions.
9. Alpha.10 smoke tests.

## Files changed

- `jarvis_v5/config.py`
- `jarvis_v5/app.py`
- `jarvis_v5/core/state_kernel.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/schemas/message_schema.py`
- `README.md`

## Files added

- `jarvis_v5/schemas/builder_engine_contract_schema.py`
- `jarvis_v5/core/engine_contract_store.py`
- `jarvis_v5/tools/builder/engine_contract_adapter.py`
- `jarvis_v5/tests/smoke/test_alpha10_engine_contract_adapter.py`
- `jarvis_v5/docs/ALPHA_10_SCOPE.md`
- `START_JARVIS_V5_ALPHA_10.bat`
- `START_JARVIS_V5_ALPHA_10_SIMPLE_NO_RELOAD.bat`
- `JARVIS_v5_0_0_alpha_10_CHANGE_REPORT.md`
- `JARVIS_v5_0_0_alpha_10_TEST_REPORT.md`
- `JARVIS_v5_0_0_alpha_10_TEST_RUN_RESULTS.txt`

## Safety locks preserved

- `workbook_read=false`
- `engine_called=false`
- `excel_created=false`
- `contract_only=true`
- `legacy_builder_called=false`

## Protected / not touched

- No Builder engine
- No Formatter
- No QA Checker
- No O&A
- No formula generation
- No workbook reading/parsing
- No sheet inspection
- No actual Preview/Export
- No UI redesign
- No current Jarvis replacement
