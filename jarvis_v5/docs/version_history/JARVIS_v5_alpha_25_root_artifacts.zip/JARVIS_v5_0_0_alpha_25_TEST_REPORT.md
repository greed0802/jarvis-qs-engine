# Jarvis v5.0.0-alpha.25 Test Report

## Runtime checks

PASS - python -m compileall -q jarvis_v5
PASS - PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
Result: 206 passed

## Retained no-engine packs

PASS - alpha25_legacy_bridge_readiness_audit_tests: 2/2
PASS - alpha24_route_ownership_registry_advisory_tests: 5/5
PASS - alpha23_global_capability_registry_tests: 7/7
PASS - alpha22_2f_engineering_language_gate_tests: 4/4
PASS - alpha22_2e_active_task_language_plan_cleanup_tests: 5/5
PASS - alpha22_2d_high_priority_ownership_repair_tests: 5/5
PASS - alpha21_function_unit_compatibility_tests: 5/5
PASS - alpha20_deep_weak_point_boundary_tests: 2/2
PASS - alpha19_contract_fixture_replay_tests: 5/5
PASS - alpha18_1_safety_envelope_tests: 5/5
PASS - alpha17_engine_execution_lock_tests: 4/4
PASS - alpha11_contract_negative_guards: 7/7

Total retained pack result: 56/56

## Safety aggregate

All retained packs reported:

```text
workbook_read_any_true=false
engine_called_any_true=false
excel_created_any_true=false
legacy_builder_called_any_true=false
```

## Protected hash result

10 / 10 protected Builder boundary files unchanged.

## Registry execution scan

execution_enabled=true count = 0
